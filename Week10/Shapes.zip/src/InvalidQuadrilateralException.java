public class InvalidQuadrilateralException extends Exception{
    public InvalidQuadrilateralException(String message){
        super(message);
    }
}
