public class InvalidTriangleException extends Exception{
    public InvalidTriangleException(String message){
        super(message);
    }
}
